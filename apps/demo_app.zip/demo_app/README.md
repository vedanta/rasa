# Demo App: Stateless LLM Persona

This app demonstrates a minimal end-to-end LLM-powered persona using the StatelessFrame in RASA.

## How to Run

From project root:

```bash
PYTHONPATH=. python apps/demo_app/main.py
```

## To Use a Mocked LLM (no API calls):

```bash
MOCK_LLM=1 PYTHONPATH=. python apps/demo_app/main.py
```

## What It Does

- Takes user input
- Passes it to the StatelessFrame
- StatelessFrame calls the configured LLM and returns output
- Prints persona output and context

## Example

```
User: Recommend a spring weekend getaway in Europe.

Persona Output:
(May vary: shows real LLM or MOCK LLM output)

Context: {'intent': 'travel_request'}
```