from rasa.frames.stateless_frame import StatelessFrame

def run_stateless_persona(user_input: str):
    frame = StatelessFrame(name="stateless")
    state = {"user_input": user_input}
    result = frame.run(state)
    return result

if __name__ == "__main__":
    # If MOCK_LLM=1 is set, monkeypatch for fast demo/testing
    import os
    if os.getenv("MOCK_LLM"):
        from rasa.frames import stateless_frame
        stateless_frame.call_llm = lambda prompt, **kwargs: f"MOCK LLM OUTPUT: {prompt}"

    user_input = input("User: ")
    result = run_stateless_persona(user_input)
    print("\nPersona Output:")
    print(result["output"])
    print("\nContext:", result.get("context"))