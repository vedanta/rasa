import yaml
from pathlib import Path
from rasa.frames.stateless_frame import StatelessFrame

def load_persona_yaml():
    with open(Path(__file__).parent / "persona.yaml") as f:
        return yaml.safe_load(f)

def run_stateless_persona(user_input: str, persona_conf: dict):
    frame = StatelessFrame(name=persona_conf["frames"][0])
    state = {"user_input": user_input}
    result = frame.run(state)
    return result

if __name__ == "__main__":
    import os
    if os.getenv("MOCK_LLM"):
        from rasa.frames import stateless_frame
        stateless_frame.call_llm = lambda prompt, **kwargs: f"MOCK LLM OUTPUT: {prompt}"

    persona_conf = load_persona_yaml()
    print(f"Persona: {persona_conf['name']} - {persona_conf['description']}")
    user_input = input("User: ")
    result = run_stateless_persona(user_input, persona_conf)
    print("\nPersona Output:")
    print(result["output"])
    print("\nContext:", result.get("context"))