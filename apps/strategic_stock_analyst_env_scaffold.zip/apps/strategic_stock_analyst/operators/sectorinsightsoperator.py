class SectorInsightsOperator:
    def run(self, state):
        state['sectorinsightsoperator'] = "SectorInsightsOperator: Not implemented"
        return state
