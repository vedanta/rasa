class ExternalDataOperator:
    def run(self, state):
        state['externaldataoperator'] = "ExternalDataOperator: Not implemented"
        return state
