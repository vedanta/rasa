class MarketTrendsFrame:
    def run(self, state):
        state['markettrendsframe'] = "MarketTrendsFrame: Not implemented"
        return state
