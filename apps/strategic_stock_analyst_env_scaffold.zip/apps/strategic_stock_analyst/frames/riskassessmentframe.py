class RiskAssessmentFrame:
    def run(self, state):
        state['riskassessmentframe'] = "RiskAssessmentFrame: Not implemented"
        return state
